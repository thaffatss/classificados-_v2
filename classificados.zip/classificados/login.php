<?php require 'pages/header.php'; ?>
<link rel="stylesheet" type="text/css" href="assets/css/login.css">

<div class="wrapper fadeInDown">
	
	<div id="formContent">
	<!-- Icon -->
	<div class="fadeIn first">

		<?php
		require 'classes/usuarios.class.php';
		$u = new Usuarios();
		if(isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['senha']) && !empty($_POST['senha'])) {
			$email = addslashes($_POST['email']);
			$senha = $_POST['senha'];

			if($u->login($email, $senha)){
				?>
				<script type="text/javascript">window.location.href="./";</script>
				<?php
			} else {
				?>
					<div class="alert alert-danger" role="alert" style="margin-bottom: 0px;">
						<button type="button" class="close" data-dismiss="alert" style="font-size: 12px; padding: 5px;">x</button>
						Usuário e/ou senha errados!
					</div>
				<?php
			}
		}
		?>

	    <img src="assets/images/logo.png" id="icon" alt="User Icon" style="width: 150px; height: 150px; margin:10px;" />
	</div>
	<!-- Login Form -->
	<form method="POST">
	    <input type="email" id="email" class="fadeIn second" name="email" placeholder="exemplo@email.com" autocomplete="off">
	    <input type="password" id="senha" class="fadeIn third" name="senha" placeholder="Digite sua senha" autocomplete="off">
	    <input type="submit" class="fadeIn fourth" value="Entrar">
	</form>
</div>
<?php require 'pages/footer.php'; ?>
<!-- Faz com quer ao entrar na tela de login o cursor do mouse fique no campo Identificação do usuário, setando o id do campo e usando o metodo .focus() -->
<script type="text/javascript">
    document.getElementById("login").focus();
</script>
