<?php require 'pages/header.php'?>
<?php
if(empty($_SESSION['cLogin'])){
    ?>
    <script type="text/javascript">window.location.href="login.php";</script>
    <?php
    exit;
}
require 'classes/anuncios.class.php';
$a = new Anuncios();
if(isset($_GET['id']) && !empty($_GET['id'])) {
    $info = $a->getAnuncio($_GET['id']);
} else {
    ?>
    <script type="text/javascript">window.location.href="meus-anuncios.php";</script>
    <?php
    exit;
}
if(isset($_POST['titulo']) && !empty($_POST['titulo'])
&& isset($_POST['categoria']) && !empty($_POST['categoria'])
&& isset($_POST['valor']) && !empty($_POST['valor'])
&& isset($_POST['estado']) && !empty($_POST['estado'])) {
    $titulo = addslashes($_POST['titulo']);
    $categoria = addslashes($_POST['categoria']);
    $valor = addslashes($_POST['valor']);
    $descricao = addslashes($_POST['descricao']);
    $estado = addslashes($_POST['estado']);
    if(isset($_FILES['fotos'])) {
        $fotos = $_FILES['fotos'];
    } else {
        $fotos = array();
    }
    if(!empty($titulo) && !empty($valor)) {
        // Adiciona todos os campos usando a função addAnuncio() estanciando da classe anuncios.class.php. 
        if($a->updateAnuncio($titulo, $categoria, $valor, $descricao, $estado, $fotos, $_GET['id'])) {
            ?>
            <br>
            <div class="container">
                <div class="alert alert-success" role="alert">
                    Anúncio Editado com Sucesso!
                    <a href="meus-anuncios.php" class="alert-link">Ir para seus anúncios!</a>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </div>
            </div>
            <?php
            } else {
            ?>
            <br>
            <div class="container">
                <div class="alert alert-success" role="alert">
                    <strong>Erro: </strong> ao Editar Anúncio!
                    <a href="meus-anuncios.php" class="alert-link">Ir para seus anúncios!</a>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </div>
            </div>
            <?php
        }
    } else {
    ?>
    <br>
    <div class="container">
        <div class="alert alert-success" role="alert">
            <strong>Aviso: </strong>Preencha os campos indicados com <strong>(*)</strong> que são obrigatórios!
            <a href="meus-anuncios.php" class="alert-link">Ir para seus anúncios!</a>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </div>
    </div>
    <?php  
    }
}
?>
<br>
<div class="container">
    <h1>Meus Anúncios - Adicinar Anúncio</h1>

    <form method="POST" enctype="multipart/form-data">

        <div class="form-group">
            <label for="categoria">Categoria*</label>
            <select name="categoria" id="categoria" class="form-control">
                <?php
                require 'classes/categorias.class.php';
                $c = new Categorias();
                $cats = $c->getLista();
                foreach($cats as $cat):
                ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo ($info['id_categoria']==$cat['id'])?'selected="selected"':''; ?>><?php echo $cat['nome']; ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="titulo">Titulo*</label>
            <input type="text" name="titulo" class="form-control" id="titulo" autocomplete="off" value="<?php echo $info['titulo']; ?>">
        </div>

        <div class="form-group">
            <label for="valor">Valor*</label>
            <input type="text" name="valor" class="form-control" id="valor" autocomplete="off" value="<?php echo $info['valor']; ?>">
        </div>

        <div class="form-group">
            <label for="descricao">Descrição</label>
            <textarea class="form-control" name="descricao" id="descricao"><?php echo $info['descricao'];?></textarea>
        </div>

        <div class="form-group">
            <label for="estado">Estado de Conservação*</label>
            <select name="estado" id="estado" class="form-control">
                <option value="0" <?php echo ($info['estado']=='0')?'selected="selected"':''; ?>>Ruim</option>
                <option value="1" <?php echo ($info['estado']=='1')?'selected="selected"':''; ?>>Bom</option>
                <option value="2" <?php echo ($info['estado']=='2')?'selected="selected"':''; ?>>Ótimo</option>
            </select>
        </div>

        <div class="form-group">
            <label for="add_foto">Fotos do Anúncio:</label><br>
            <input type="file" name="fotos[]" multiple><br><br>

            <div class="card">
                <div class="card-header">Fotos do Anúncio</div>
                <div class="card-body">
                    <?php foreach($info['foto'] as $foto): ?>
                        <div class="foto_item">
                            <img src="assets/images/anuncios/<?php echo $foto['url']; ?>" alt="<?php $foto['foto'] ?>" class="img-thumbmail" border="0">
                            <a href="excluir-foto.php?id=<?php echo $foto['id']; ?>" class="btn btn-danger">Excluir Imagem</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Modal Confirma Exclusão -->
        <div class="modal" id="confirmar" tabindex="-1" role="dialog">
            <div class="modal-dialog" id="modal-dialog-del" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Aviso</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                            <p>Tem certeza que deseja editar esse anúncio?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Fechar</button>
                        <input type="submit" value="Confirmar" class="btn btn-outline-success">
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Confirma Exclusão FIM -->
        <button type="button" class="btn btn-outline-success btn-lg btn-block" data-toggle="modal" data-target="#confirmar">Salvar</button>
    </form>
</div>
<script type="text/javascript" src="assets/js/script.js"></script>
<?php require 'pages/footer.php'; ?>