<?php require 'pages/header.php'; ?>
<?php 
require 'classes/anuncios.class.php';
$a = new Anuncios();

require 'classes/usuarios.class.php';
$u = new Usuarios();

$total_anuncios = $a->getTotalAnuncios();
$total_usuarios = $u->getTotalUsuarios();

$msg_anuncio = "";
$msg_usuario = "";

// Verifica quantidade de anuncios e usuários para mostrar no plural.
if($total_anuncios > 1) {
    $msg_anuncio = "anúncios!";
} else {
    $msg_anuncio = "anúncio!";
}

if($total_anuncios == "") {
    $msg_anuncio = "nenhum anúncio!";
}
if($total_usuarios > 1) {
    $msg_usuario = "usuários cadastrados.";
} else {
    $msg_usuario = "usuário cadastrado.";
}

if($total_usuarios == "") {
    $msg_usuario = "nenhum usuário cadastrado.";
}

$p = 1;
if(isset($_GET['p']) && !empty($_GET['p'])) {
    $p = addslashes($_GET['p']);
}

// Define a quantidade de páginas. A função ceil() arredonda números quebrados.
$por_pagina = 2;
$total_paginas = ceil($total_anuncios / $por_pagina);

// Passa por parametro o numéro da página e quantidade de anúncios que será exibido.
$anuncios = $a->getUltimosAnuncios($p, $por_pagina);
?>
<div class="container-fluid">
    <!-- Slider main container -->
    <div class="swiper-container">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide"><img src="assets/images/banners/banner1.png" alt=""></div>
                <div class="swiper-slide"><img src="assets/images/banners/banner2.png" alt=""></div>
                <div class="swiper-slide">Slide 3</div>
            </div>
            <!-- If we need navigation buttons -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
    </div>
</div>
    <script>
        var mySwiper = new Swiper('.swiper-container', {
        // Optional parameters
        direction: 'vertical',
        loop: true,

        // If we need pagination
        pagination: {
            el: '.swiper-pagination',
        },

        // Navigation arrows
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },

        // And if we need scrollbar
        scrollbar: {
            el: '.swiper-scrollbar',
        },
        })
    </script>
<br>
</div>
<div class="container">
    <div class="jumbotron" style="background-color:#deebf9;">
        <h1 class="display-4">Nós temos hoje <?php echo $total_anuncios; ?> <?php echo $msg_anuncio; ?></h1>
        <p class="lead">É mais de <?php echo $total_usuarios; ?>  <?php echo $msg_usuario; ?></p>
        <hr class="my-4">
        <p>Não perca mais tempo, faça já seu anúncio!</p>
        <a class="btn btn-primary btn-lg" href="cadastre-se.php" role="button">Anúnciar</a>
    </div>    
    <div class="row">
        <div class="col-sm-3">
            <h5>Pesquisa Avançada</h5>
        </div>
        <div class="col-sm-9">
            <h5>Últimos Anúncios</h5>
            <table class="table table-striped">
            <tbody>
                <?php foreach($anuncios as $anuncio): ?>
                    <tr>
                        <td>
                        <!-- Verifica se tem alguma imagem cadastrada para o anuncio, caso contrario coloca imagem default.png -->
                        <?php if(!empty($anuncio['url'])): ?>
                            <td><img src="assets/images/anuncios/<?php echo $anuncio['url'] ?>" alt="Foto Anúncio" borer="0" height="80"></td>
                        <?php else: ?>
                            <td><img src="assets/images/default.png" alt="Anúncio Sem Foto" borer="0" height="80"></td>
                        <?php endif; ?>
                        </td>
                        <td>
                            <a href="produto.php?id=<?php echo $anuncio['id']; ?>"><?php echo $anuncio['titulo']; ?></a><br>
                            <?php echo $anuncio['categoria']; ?>
                        </td>
                        <td>
                            <?php echo number_format($anuncio['valor'], 2, ',', '.'); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
            <nav aria-label="Navegação de página exemplo">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="">Anterior</a></li>
                    <?php for($q=1; $q<=$total_paginas;$q++): ?>
                        <li class="<?php echo ($p==$q)?'active':''; ?> page-item"><a class="page-link" href="index.php?p=<?php echo $q; ?>"><?php echo $q; ?></a></li>
                    <?php endfor ?>
                    <li class="page-item"><a class="page-link" href="#">Próximo</a></li>
                </ul>
            </nav>
        </div>
    </div>    
</div>
<?php require 'pages/footer.php'; ?>