<?php require 'pages/header.php'?>
<?php
if(empty($_SESSION['cLogin'])){
    ?>
    <script type="text/javascript">window.location.href="login.php";</script>
    <?php
    exit;
}
?>
<div class="container">
    <h1>Meus Anúncios</h1>
        <div class="row justify-content-end">
            <div class="col-xl-0">
                <a href="add-anuncio.php">
                    <img src="assets/images/add-anuncio.svg" alt="Adicionar Anúncio">
                </a>
            </div>
        </div>
    <br>
    <table class="table table-hover">
        <thead class="thead-dark" style="text-align: center;">
            <tr>
                <th scope="col">Fotos</th>
                <th scope="col">Titulo</th>
                <th scope="col">Valor</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <?php
        require 'classes/anuncios.class.php';
        $a = new Anuncios();
        // Lista todos os anuncios e salva em $anuncios.
        $anuncios = $a->getMeusAnuncios();
        foreach ($anuncios as $anuncio):
        ?>
        <tr style="text-align: center;">
        <!-- Verifica se tem alguma imagem cadastrada para o anuncio, caso contrario coloca imagem default.png -->
            <?php if(!empty($anuncio['url'])): ?>
                <td><img src="assets/images/anuncios/<?php echo $anuncio['url'] ?>" alt="Foto Anúncio" borer="0" height="80"></td>
            <?php else: ?>
                <td><img src="assets/images/default.png" alt="Anúncio Sem Foto" borer="0" height="80"></td>
            <?php endif; ?>
            <td><?php echo $anuncio['titulo']; ?></td>
            <td><?php echo number_format($anuncio['valor'], 2, ',', '.'); ?></td>
            <td>
                <a href="editar-anuncio.php?id=<?php echo $anuncio['id']; ?>" class="btn btn-primary">Editar</a>
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmar">Excluir</button>

                <!-- Modal Confirma Exclusão -->
                <div class="modal" id="confirmar" tabindex="-1" role="dialog">
                    <div class="modal-dialog" id="modal-dialog-del" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Aviso</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>Tem certeza que deseja excluir esse anúncio?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Fechar</button>
                                <a href="excluir-anuncio.php?id=<?php echo $anuncio['id']; ?>" class="btn btn-outline-danger">Confirmar</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal Confirma Exclusão FIM -->
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<script type="text/javascript" src="assets/js/script.js"></script>
<?php require 'pages/footer.php'?>