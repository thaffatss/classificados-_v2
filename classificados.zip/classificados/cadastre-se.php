<?php require 'pages/header.php'; ?>
<br>
<div class="container">
    <h1>Cadastre-se</h1>
            <?php
                // Inicia o uso das classes.
                require 'classes/usuarios.class.php';
                $u = new Usuarios();
                // Termina usar classe usuarios.
                
                // Verifica se os valores existem e não estão vazios.
                if(isset($_POST['nome']) && !empty($_POST['nome'])
                && isset($_POST['email']) && !empty($_POST['email'])
                && isset($_POST['senha']) && !empty($_POST['senha'])
                && isset($_POST['confSenha']) && !empty($_POST['confSenha'])
                && isset($_POST['telefone']) && !empty($_POST['telefone'])) {
                    $nome = addslashes(ucwords($_POST['nome']));
                    $email = addslashes($_POST['email']);
                    $senha = ($_POST['senha']);
                    $confSenha = ($_POST['confSenha']);
                    $telefone = addslashes($_POST['telefone']);

                    // Verifica se todos os campos foram preenchidos ao enviar o formulário.
                    if(!empty($nome) && !empty($email) && !empty($senha) && !empty($telefone)) {
                        // Verifica se a senha de confirmação é a mesma.
                        if($senha == $confSenha) {
                            // Verifica se a senha digitada tem até 6 caracteres incluindo letras, números e caracteres especiais.
                            if(preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[\w$@]{6,}$/', $senha) && preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[\w$@]{6,}$/', $confSenha)) {
                                // O registro mostra uma mensagem de sucesso.
                                if($u->cadastrar($nome, $email, $senha, $confSenha, $telefone)) {
                                    ?>
                                    <div class="alert alert-success" role="alert">
                                        <strong>Parabéns!</strong> Cadastrado com sucesso. 
                                        <a href="login.php" class="alert-link">Faça o login agora</a>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </div>
                                    <?php
                                } else {
                                    ?>
                                    <div class="alert alert-warning" role="alert">
                                            Este usuário já existe!
                                        <a href="login.php" class="alert-link">Faça o login agora</a>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </div>
                                    <?php
                                }
                            } else {
                                ?>
                                <div class="alert alert-warning" role="alert">
                                    <strong>Aviso: </strong> A senha precisa ter até 6 caracteres incluindo letras, números e caracateres especiais. <strong>Tente novamente!</strong>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </div>
                                <?php
                            } 
                        } else {
                                ?>
                                <div class="alert alert-warning" role="alert">
                                    <strong>Campo Confirmar: </strong> Senhas não conferem, <strong>tente novamente!</strong>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </div>
                                <?php
                        }
                    } else {
                        ?>
                            <div class="alert alert-warning" role="alert">
                                <strong>Aviso: </strong>Preencha os campos indicados com <strong>(*)</strong> que são obrigatórios!
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </div>
                        <?php
                    }
                        
                }
            ?>
            <form method="POST">
            <div class="form-group">
                <label for="nome">Nome*</label>
                <input type="text" name="nome" class="form-control" id="nome" aria-describedby="emailHelp" autocomplete="off" placeholder="Digite seu nome">
            </div>

            <div class="form-group">
                <label for="email">E-mail*</label>
                <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Digite seu e-mail">
                <small id="emailHelp" class="form-text text-muted">Nunca compartilharemos seu email com mais ninguém.</small>
            </div>

            <div class="form-group">
                <label for="senha">Senha*</label>
                <input type="password" name="senha" class="form-control" id="senha" autocomplete="off" placeholder="Digite sua senha">
            </div>

            <div class="form-group">
                <label for="confSenha">Confirmar*</label>
                <input type="password" name="confSenha" class="form-control" id="confSenha" autocomplete="off" placeholder="Confirme sua senha">
                <small id="emailHelp" class="form-text text-muted">Apenas letras e números <strong>Ex: kYd10T2</strong></small>
            </div>

            <div class="form-group">
                <label for="telefone">Telefone*</label>
                <input type="text" name="telefone" class="form-control" id="telefone" autocomplete="off" placeholder="Digite seu número de telefone">
            </div>

            <input type="submit" value="Cadastrar" class="btn btn-outline-success btn-lg btn-block">

            </form>
        </div>
</div>
<script type="text/javascript" src="assets/js/script.js"></script>
<?php require 'pages/footer.php'; ?>