<?php
class Usuarios {

    public function getTotalUsuarios() {
        global $pdo;

        $sql = $pdo->query("SELECT COUNT(*) as c FROM usuarios");
        $row = $sql->fetch();

        return $row['c'];
    }

    public function cadastrar($nome, $email, $senha, $confSenha, $telefone) {
        global $pdo;
        // Select user id when email equals email.
        $sql = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email");
        $sql->bindValue(":email", $email);
        $sql->execute();

        // If the number of users returned is equal to 0, then I do the insertion.
        if($sql->rowCount() == 0) {
            
            $sql = $pdo->prepare("INSERT INTO usuarios SET nome = :nome, 
            email = :email, senha = :senha, confSenha = :confSenha, telefone = :telefone");
            $sql->bindValue(":nome", $nome);
            $sql->bindValue(":email", $email);
            $sql->bindValue(":senha", md5($senha));
            $sql->bindValue(":confSenha", md5($confSenha));
            $sql->bindValue(":telefone", $telefone);
            $sql->execute();

            return true;

        }else {
            return false;
        }

    }

    public function login($email, $senha) {
        global $pdo;
    
        // Faz validação
        $sql = $pdo->prepare("SELECT id, nome FROM usuarios WHERE email = :email AND senha = :senha");
        $sql->bindValue(":email", $email);
        $sql->bindValue(":senha", md5($senha));
        $sql->execute();
    
        // Verifica se tem algum usuario com email e senha.
        if($sql->rowCount() > 0) {
            $dado = $sql->fetch();
            $_SESSION['cLogin'] = $dado['id'];
            $_SESSION['nomeUser'] = $dado['nome'];
    
            return true;
        } else {
            return false;
        }
    }
}
?>