<?php require 'pages/header.php'; ?>
<?php 
require 'classes/anuncios.class.php';
$a = new Anuncios();

if(isset($_GET['id']) && !empty($_GET['id'])) {
    $id = addslashes($_GET['id']);
} else {
    ?>
    <script type="text/javascript">window.location.href="index.php";</script>
    <?php
    exit;
}
$info = $a->getAnuncio($id);
?>
<br>
<div class="container">
    <div class="row">
        <div class="col-sm-5">
            <div class="carousel slide" data-ride="carousel" id="meuCarousel">
                <div class="carousel-inner" role="listbox">
                    <?php foreach($info['foto'] as $chave => $foto): ?>
                        <div class="item <?php echo ($chave=='0')?'active':''; ?>">
                            <img src="assets/images/anuncios/<?php echo $foto['url']; ?>" alt="Fotos do Anúncio">
                        </div>
                    <?php endforeach; ?>
                </div>
                <a class="carousel-control-prev" href="#meuCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Anterior</span>
                </a>
                <a class="carousel-control-next" href="#meuCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Próximo</span>
                </a>
            </div>
        </div>
    <div class="col-sm-7">
        ...
    </div>
    </div>    
</div>
<?php require 'pages/footer.php'; ?>