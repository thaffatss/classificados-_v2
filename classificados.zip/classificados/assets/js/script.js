$(function(){

	$('#modal').on('click', function(e){
		e.preventDefault();

		$('.modal-body').html('Carregando...');
		$('.modal').show();

		var link = $(this).attr('href');

		$.ajax({
			url:link,
			type:'GET',
			success:function(html){
				$('.modal-body').html(html);
			}
		});
	});
});

$(function() {
	$(document).ready(function(){
		//$('#valor').mask("##.##0,00", {reverse: true});
		$('input[name=cod]').mask("#", {reverse: true});
		$('input[name=number]').mask("#", {reverse: true});
		$('#telefone').mask("(00) 0 0000-0000", {reverse: false});
	})
});