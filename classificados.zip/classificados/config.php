<?php
//Inicia Sessão.
session_start();
// Inicia Conexão com o Banco de Dados.

global $pdo;

try {
    $pdo = new PDO("mysql:dbname=classificados;host=localhost", "root", "");
} catch(PDOException $e) {
    echo "FALHOU: ".$e->getMessage();
    exit;
}
?>