<?php require 'pages/header.php'?>
<br>
<?php
if(empty($_SESSION['cLogin'])){
    ?>
    <script type="text/javascript">window.location.href="login.php";</script>
    <?php
    exit;
}
require 'classes/anuncios.class.php';
$a = new Anuncios();
if(isset($_POST['titulo']) && !empty($_POST['titulo'])
&& isset($_POST['categoria']) && !empty($_POST['categoria'])
&& isset($_POST['valor']) && !empty($_POST['valor'])
&& isset($_POST['estado']) && !empty($_POST['estado'])) {
    $titulo = addslashes($_POST['titulo']);
    $categoria = addslashes($_POST['categoria']);
    $valor = addslashes($_POST['valor']);
    $descricao = addslashes($_POST['descricao']);
    $estado = addslashes($_POST['estado']);

    if(!empty($titulo) && !empty($valor)) {
        // Adiciona todos os campos usando a função addAnuncio() estanciando da classe anuncios.class.php. 
        if($a->addAnuncio($titulo, $categoria, $valor, $descricao, $estado)) {
            ?> 
            <div class="container">
                <div class="alert alert-success" role="alert">
                    Anúncio feito com sucesso!
                    <a href="meus-anuncios.php" class="alert-link">Ir para seus anúncios!</a>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </div>
            </div>
            <?php
            } else {
            ?>
            <div class="container">
                <div class="alert alert-success" role="alert">
                    <strong>Erro: </strong> ao criar anúncio!
                    <a href="meus-anuncios.php" class="alert-link">Ir para seus anúncios!</a>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </div>
            </div>
            <?php
        }
    } else {
    ?>
    <div class="container">
        <div class="alert alert-success" role="alert">
            <strong>Aviso: </strong>Preencha os campos indicados com <strong>(*)</strong> que são obrigatórios!
            <a href="meus-anuncios.php" class="alert-link">Ir para seus anúncios!</a>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </div>
    </div>
    <?php  
    }
}
?>
<br>
<div class="container">
    <h1>Meus Anúncios - Adicinar Anúncio</h1>

    <form method="POST" enctype="multipart/form-data">

        <div class="form-group">
            <label for="categoria">Categoria*</label>
            <select name="categoria" id="categoria" class="form-control">
                <?php
                require 'classes/categorias.class.php';
                $c = new Categorias();
                $cats = $c->getLista();
                foreach($cats as $cat):
                ?>
                    <option value="<?php echo $cat['id']; ?>"><?php echo $cat['nome']; ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="titulo">Titulo*</label>
            <input type="text" name="titulo" class="form-control" id="titulo" autocomplete="off" placeholder="Digite o Titulo do Anúncio">
        </div>

        <div class="form-group">
            <label for="valor">Valor*</label>
            <input type="text" name="valor" class="form-control" id="valor" autocomplete="off" placeholder="Digite o Valor">
        </div>

        <div class="form-group">
            <label for="descricao">Descrição</label>
            <textarea class="form-control" name="descricao" id="descricao"></textarea>
        </div>

        <div class="form-group">
            <label for="estado">Estado de Conservação*</label>
            <select name="estado" id="estado" class="form-control">
                <option value="0">Ruim</option>
                <option value="1">Bom</option>
                <option value="2">Ótimo</option>
            </select>
        </div>
        <br>
        <br>
        <br>
        <input type="submit" value="Adicionar" class="btn btn-outline-success btn-lg btn-block">
    </form>
</div>
<script type="text/javascript" src="assets/js/script.js"></script>
<?php require 'pages/footer.php'; ?>